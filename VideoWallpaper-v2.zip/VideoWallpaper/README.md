# Video Live Wallpaper (v2)

Pick any video on your phone and use it as a looping live wallpaper.

## Features
- Infinite loop, hardware decoded, no libraries (tiny APK)
- Sound on/off with volume slider (muted by default)
- Quality: 480p / 720p / 1080p / Max (Max = full native screen resolution)
- Speed: 0.5x / 1x / 1.5x / 2x
- Framing: Fill screen (crop) or Stretch
- Freeze in Battery Saver (shows a still frame instead of playing)
- Recent videos with thumbnails (tap to switch, long-press to remove)
- iOS-inspired liquid-glass interface

## Build & install
Android Studio: open this folder, let Gradle sync, press Run (or Build > Build APK(s)).
Or let GitHub build it: see the workflow in the chat.

## Use
1. Open the app, tap **Choose video**.
2. Tap **Set wallpaper** in Android's preview.
3. Change sound / quality / speed any time; the live wallpaper updates instantly.

## How it stays light
- Pauses the moment the wallpaper isn't visible; frees the decoder after 20 s hidden.
- No touch handling, timers or background services.
- Quality only changes the render resolution; your video file is never re-encoded.
