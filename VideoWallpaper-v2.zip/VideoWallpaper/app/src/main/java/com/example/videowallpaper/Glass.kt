package com.example.videowallpaper

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

val IOS_BLUE: Int = Color.parseColor("#0A84FF")
val IOS_GREEN: Int = Color.parseColor("#34C759")
val TEXT_PRIMARY: Int = Color.WHITE
val TEXT_SECONDARY: Int = Color.parseColor("#B3FFFFFF")

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

/** Frosted "liquid glass" surface: soft top-to-bottom sheen plus a thin bright rim. */
fun glass(ctx: Context, radiusDp: Int, strong: Boolean = false): GradientDrawable {
    val top = if (strong) 0x52FFFFFF else 0x30FFFFFF
    val bottom = if (strong) 0x1FFFFFFF else 0x0FFFFFFF
    return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom)).apply {
        cornerRadius = ctx.dp(radiusDp).toFloat()
        setStroke(ctx.dp(1), 0x44FFFFFF)
    }
}

fun solid(ctx: Context, color: Int, radiusDp: Int): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = ctx.dp(radiusDp).toFloat()
    }

fun View.roundClip(radiusPx: Float) {
    outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, radiusPx)
        }
    }
    clipToOutline = true
}

/** iOS-style squish when pressed. */
fun View.pressable() {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN ->
                v.animate().scaleX(0.97f).scaleY(0.97f).setDuration(90).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
        }
        false
    }
}

fun styledSwitch(ctx: Context, checked: Boolean, onChange: (Boolean) -> Unit): Switch =
    Switch(ctx).apply {
        isChecked = checked
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        trackTintList = ColorStateList(states, intArrayOf(IOS_GREEN, 0x66FFFFFF))
        thumbTintList = ColorStateList.valueOf(Color.WHITE)
        setOnCheckedChangeListener { _, c -> onChange(c) }
    }

/** Static, GPU-cheap ambient background: a few soft colour glows on a dark base. */
class GlassBackground(ctx: Context) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val base = Color.parseColor("#0B0D1A")
    private var glows: List<Shader> = emptyList()

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        fun glow(cx: Float, cy: Float, r: Float, color: Int): Shader =
            RadialGradient(
                cx, cy, r,
                intArrayOf(Color.argb(190, Color.red(color), Color.green(color), Color.blue(color)), Color.TRANSPARENT),
                null, Shader.TileMode.CLAMP
            )
        val s = maxOf(w, h).toFloat()
        glows = listOf(
            glow(w * 0.10f, h * 0.08f, s * 0.60f, Color.parseColor("#2D6BFF")),
            glow(w * 0.95f, h * 0.42f, s * 0.55f, Color.parseColor("#9B3DFF")),
            glow(w * 0.20f, h * 0.95f, s * 0.60f, Color.parseColor("#FF4D8D"))
        )
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(base)
        for (g in glows) {
            paint.shader = g
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        }
    }
}

/** iOS-style segmented control. */
class Segmented(
    ctx: Context,
    labels: List<String>,
    selected: Int,
    private val onPick: (Int) -> Unit
) : LinearLayout(ctx) {

    private val cells = ArrayList<TextView>()

    init {
        orientation = HORIZONTAL
        background = GradientDrawable().apply {
            cornerRadius = ctx.dp(12).toFloat()
            setColor(0x33000000)
            setStroke(ctx.dp(1), 0x22FFFFFF)
        }
        setPadding(ctx.dp(3), ctx.dp(3), ctx.dp(3), ctx.dp(3))
        labels.forEachIndexed { i, label ->
            val t = TextView(ctx).apply {
                text = label
                gravity = Gravity.CENTER
                textSize = 14f
                setTextColor(TEXT_PRIMARY)
                setPadding(0, ctx.dp(8), 0, ctx.dp(8))
                setOnClickListener {
                    select(i)
                    onPick(i)
                }
            }
            addView(t, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            cells.add(t)
        }
        select(selected)
    }

    fun select(index: Int) {
        cells.forEachIndexed { i, t ->
            val on = i == index
            t.background = if (on) solid(context, 0x66FFFFFF, 9) else null
            t.typeface = if (on) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
    }
}
