package com.example.videowallpaper

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val KEY_VIDEO = "video_uri"
    const val KEY_RECENT = "recent"
    const val KEY_SOUND = "sound"
    const val KEY_VOLUME = "volume"
    const val KEY_QUALITY = "quality"
    const val KEY_SPEED = "speed"
    const val KEY_CROP = "crop"
    const val KEY_SAVER = "freeze_saver"

    const val MAX_RECENT = 8
    private const val NAME = "video_wallpaper"

    fun get(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun videoUri(c: Context): String? = get(c).getString(KEY_VIDEO, null)
    fun sound(c: Context): Boolean = get(c).getBoolean(KEY_SOUND, false)
    fun volume(c: Context): Int = get(c).getInt(KEY_VOLUME, 60)

    /** 0 = max (native screen resolution), otherwise the short side in pixels: 480 / 720 / 1080. */
    fun quality(c: Context): Int = get(c).getInt(KEY_QUALITY, 0)
    fun speed(c: Context): Float = get(c).getFloat(KEY_SPEED, 1f)

    /** true = fill screen by cropping, false = stretch to the screen. */
    fun crop(c: Context): Boolean = get(c).getBoolean(KEY_CROP, true)
    fun freezeOnSaver(c: Context): Boolean = get(c).getBoolean(KEY_SAVER, true)

    fun recent(c: Context): List<String> {
        val list = get(c).getString(KEY_RECENT, null)
            ?.split("\n")?.filter { it.isNotBlank() } ?: emptyList()
        if (list.isNotEmpty()) return list
        return videoUri(c)?.let { listOf(it) } ?: emptyList()
    }

    /** Makes [uri] the current video and moves it to the front. Returns URIs that fell off the list. */
    fun select(c: Context, uri: String): List<String> {
        val list = recent(c).toMutableList()
        list.remove(uri)
        list.add(0, uri)
        val kept = list.take(MAX_RECENT)
        val dropped = list.drop(MAX_RECENT)
        get(c).edit()
            .putString(KEY_RECENT, kept.joinToString("\n"))
            .putString(KEY_VIDEO, uri)
            .apply()
        return dropped
    }

    fun remove(c: Context, uri: String) {
        val list = recent(c).filter { it != uri }
        val e = get(c).edit().putString(KEY_RECENT, list.joinToString("\n"))
        if (videoUri(c) == uri) {
            if (list.isEmpty()) e.remove(KEY_VIDEO) else e.putString(KEY_VIDEO, list[0])
        }
        e.apply()
    }
}
