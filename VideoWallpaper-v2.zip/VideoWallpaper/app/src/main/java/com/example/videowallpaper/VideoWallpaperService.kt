package com.example.videowallpaper

import android.content.Context
import android.content.SharedPreferences
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder

// After the wallpaper has been hidden this long (screen off, app in front),
// the decoder is released completely so it uses zero resources.
private const val IDLE_RELEASE_MS = 20_000L

class VideoWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = VideoEngine()

    private inner class VideoEngine : Engine() {

        private val ctx: Context get() = this@VideoWallpaperService
        private val handler = Handler(Looper.getMainLooper())
        private val prefs = Prefs.get(this@VideoWallpaperService)
        private val power by lazy { getSystemService(Context.POWER_SERVICE) as PowerManager }

        private var player: MediaPlayer? = null
        private var prepared = false
        private var loadedUri: String? = null
        private var savedPosition = 0
        private var surfaceReady = false
        private var visible = false

        private val releaseWhenIdle = Runnable { releasePlayer(keepPosition = true) }

        // Strong reference is required: SharedPreferences only holds listeners weakly.
        private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            when (key) {
                Prefs.KEY_VIDEO -> {
                    savedPosition = 0
                    releasePlayer(keepPosition = false)
                    if (visible && surfaceReady) startPlayback()
                }
                Prefs.KEY_QUALITY -> applyQuality()
                Prefs.KEY_SOUND, Prefs.KEY_VOLUME -> player?.let { applyVolume(it) }
                Prefs.KEY_SPEED -> player?.let { if (prepared && it.isPlaying) applySpeed(it) }
                Prefs.KEY_CROP -> player?.let { if (prepared) applyScaling(it) }
                else -> Unit
            }
        }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            setTouchEventsEnabled(false) // no touch handling = less work
            prefs.registerOnSharedPreferenceChangeListener(prefListener)
            applyQuality()
        }

        override fun onSurfaceCreated(holder: SurfaceHolder) {
            super.onSurfaceCreated(holder)
            surfaceReady = true
            if (visible) startPlayback()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            surfaceReady = false
            releasePlayer(keepPosition = true)
            super.onSurfaceDestroyed(holder)
        }

        override fun onVisibilityChanged(visible: Boolean) {
            this.visible = visible
            if (visible) {
                if (surfaceReady) startPlayback()
            } else {
                pausePlayback()
            }
        }

        override fun onDestroy() {
            handler.removeCallbacksAndMessages(null)
            prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
            releasePlayer(keepPosition = false)
            super.onDestroy()
        }

        private fun shouldPlay(): Boolean =
            visible && surfaceReady &&
                !(Prefs.freezeOnSaver(ctx) && power.isPowerSaveMode)

        /**
         * Quality = the resolution the wallpaper is rendered at. "Max" uses the screen's full
         * native resolution. Lower values render smaller and let the system scale it up, which
         * saves GPU/battery. The video file itself is never re-encoded or modified.
         */
        private fun applyQuality() {
            val q = Prefs.quality(ctx)
            val dm = ctx.resources.displayMetrics
            val w = dm.widthPixels
            val h = dm.heightPixels
            val shortSide = minOf(w, h)
            if (q == 0 || q >= shortSide) {
                surfaceHolder.setSizeFromLayout()
            } else {
                val s = q.toFloat() / shortSide
                surfaceHolder.setFixedSize(
                    (w * s).toInt().coerceAtLeast(2),
                    (h * s).toInt().coerceAtLeast(2)
                )
            }
        }

        private fun applyVolume(p: MediaPlayer) {
            val v = if (Prefs.sound(ctx)) Prefs.volume(ctx) / 100f else 0f
            try {
                p.setVolume(v, v)
            } catch (_: Exception) {
            }
        }

        private fun applySpeed(p: MediaPlayer) {
            try {
                p.playbackParams = PlaybackParams().setSpeed(Prefs.speed(ctx))
            } catch (_: Exception) {
            }
        }

        private fun applyScaling(p: MediaPlayer) {
            try {
                p.setVideoScalingMode(
                    if (Prefs.crop(ctx)) MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING
                    else MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT
                )
            } catch (_: Exception) {
            }
        }

        private fun startPlayback() {
            handler.removeCallbacks(releaseWhenIdle)

            val uriString = Prefs.videoUri(ctx) ?: return

            // Fast path: same video already loaded, just resume.
            val current = player
            if (current != null && loadedUri == uriString) {
                if (prepared && !current.isPlaying && shouldPlay()) {
                    try {
                        current.start()
                        applySpeed(current)
                    } catch (_: Exception) {
                    }
                }
                return
            }

            releasePlayer(keepPosition = false)
            try {
                val mp = MediaPlayer()
                mp.setSurface(surfaceHolder.surface)
                mp.setDataSource(applicationContext, Uri.parse(uriString))
                mp.isLooping = true // infinite loop
                applyVolume(mp)
                mp.setOnPreparedListener { p ->
                    prepared = true
                    applyScaling(p)
                    applyVolume(p)
                    // Always seek: it also draws a frame on the surface when we are not playing.
                    val pos = savedPosition
                    savedPosition = 0
                    p.seekTo(pos)
                    if (shouldPlay()) {
                        p.start()
                        applySpeed(p)
                    }
                }
                mp.setOnErrorListener { _, _, _ ->
                    releasePlayer(keepPosition = false)
                    true
                }
                player = mp
                loadedUri = uriString
                prepared = false
                mp.prepareAsync()
            } catch (_: Exception) {
                releasePlayer(keepPosition = false)
            }
        }

        private fun pausePlayback() {
            player?.let { p ->
                try {
                    if (prepared && p.isPlaying) p.pause()
                } catch (_: Exception) {
                }
            }
            handler.removeCallbacks(releaseWhenIdle)
            handler.postDelayed(releaseWhenIdle, IDLE_RELEASE_MS)
        }

        private fun releasePlayer(keepPosition: Boolean) {
            handler.removeCallbacks(releaseWhenIdle)
            player?.let { p ->
                savedPosition = if (keepPosition && prepared) {
                    try {
                        p.currentPosition
                    } catch (_: Exception) {
                        0
                    }
                } else {
                    0
                }
                try {
                    p.setOnPreparedListener(null)
                    p.setOnErrorListener(null)
                    p.release()
                } catch (_: Exception) {
                }
            }
            player = null
            prepared = false
            loadedUri = null
        }
    }
}
