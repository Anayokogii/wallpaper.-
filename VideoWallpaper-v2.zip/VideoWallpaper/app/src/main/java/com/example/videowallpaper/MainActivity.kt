package com.example.videowallpaper

import android.app.Activity
import android.app.WallpaperManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.TextUtils
import android.util.LruCache
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private val io: ExecutorService = Executors.newSingleThreadExecutor()
    private val cache = LruCache<String, Bitmap>(24)

    private lateinit var previewImg: ImageView
    private lateinit var previewEmpty: TextView
    private lateinit var nameTv: TextView
    private lateinit var infoTv: TextView
    private lateinit var applyBtn: TextView
    private lateinit var recentSection: LinearLayout
    private lateinit var recentRow: LinearLayout

    private val qualityValues = listOf(480, 720, 1080, 0)
    private val speedValues = listOf(0.5f, 1f, 1.5f, 2f)

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULL_SCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        val root = FrameLayout(this)
        root.addView(GlassBackground(this), FrameLayout.LayoutParams(MATCH, MATCH))

        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(32))
        }
        scroll.addView(content, ViewGroup.LayoutParams(MATCH, WRAP))
        root.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))
        scroll.setOnApplyWindowInsetsListener { v, insets ->
            v.setPadding(0, insets.systemWindowInsetTop, 0, insets.systemWindowInsetBottom)
            insets
        }

        buildUi(content)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        io.shutdownNow()
        super.onDestroy()
    }

    // ───────────────────────────── UI ─────────────────────────────

    private fun buildUi(content: LinearLayout) {
        content.addView(text("Video Wallpaper", 34f, TEXT_PRIMARY, bold = true).apply {
            setPadding(dp(4), dp(16), 0, 0)
        })
        content.addView(text("Any video, looping live on your screen.", 15f, TEXT_SECONDARY).apply {
            setPadding(dp(4), dp(2), 0, dp(18))
        })

        // Preview card
        val preview = card(strong = true, pad = 10)
        val frame = FrameLayout(this)
        previewImg = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = solid(this@MainActivity, 0x22000000, 20)
            roundClip(dp(20).toFloat())
        }
        previewEmpty = text("No video yet", 16f, TEXT_SECONDARY).apply { gravity = Gravity.CENTER }
        frame.addView(previewImg, FrameLayout.LayoutParams(MATCH, MATCH))
        frame.addView(previewEmpty, FrameLayout.LayoutParams(MATCH, MATCH))
        preview.addView(frame, LinearLayout.LayoutParams(MATCH, dp(240)))

        nameTv = text("", 17f, TEXT_PRIMARY, bold = true).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.MIDDLE
            setPadding(dp(6), dp(12), dp(6), 0)
        }
        infoTv = text("", 13f, TEXT_SECONDARY).apply { setPadding(dp(6), dp(2), dp(6), dp(4)) }
        preview.addView(nameTv)
        preview.addView(infoTv)
        content.addView(preview)

        // Buttons
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val choose = pill("Choose video", filled = false).apply { setOnClickListener { pickVideo() } }
        applyBtn = pill("Set as wallpaper", filled = true).apply { setOnClickListener { openWallpaperSetter() } }
        buttons.addView(choose, LinearLayout.LayoutParams(0, dp(52), 1f).apply { rightMargin = dp(10) })
        buttons.addView(applyBtn, LinearLayout.LayoutParams(0, dp(52), 1.3f))
        content.addView(buttons, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14) })

        // Sound
        content.addView(sectionLabel("SOUND"))
        val soundCard = card()
        val volumeLabel = text("${Prefs.volume(this)}%", 15f, TEXT_SECONDARY)
        val volumeSeek = SeekBar(this).apply {
            max = 100
            progress = Prefs.volume(this@MainActivity)
            progressTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(0x44FFFFFF)
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    volumeLabel.text = "$p%"
                    if (fromUser) Prefs.get(this@MainActivity).edit().putInt(Prefs.KEY_VOLUME, p).apply()
                }

                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        val volumeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, 0)
        }
        volumeRow.addView(volumeSeek, LinearLayout.LayoutParams(0, WRAP, 1f))
        volumeRow.addView(volumeLabel, LinearLayout.LayoutParams(dp(48), WRAP).apply { leftMargin = dp(8) })
        fun syncVolumeEnabled(on: Boolean) {
            volumeSeek.isEnabled = on
            volumeRow.alpha = if (on) 1f else 0.4f
        }
        soundCard.addView(row("Play video sound", styledSwitch(this, Prefs.sound(this)) { on ->
            Prefs.get(this).edit().putBoolean(Prefs.KEY_SOUND, on).apply()
            syncVolumeEnabled(on)
        }))
        soundCard.addView(volumeRow)
        syncVolumeEnabled(Prefs.sound(this))
        content.addView(soundCard)

        // Quality
        content.addView(sectionLabel("QUALITY"))
        val qualityCard = card()
        val qIndex = qualityValues.indexOf(Prefs.quality(this)).let { if (it < 0) 3 else it }
        qualityCard.addView(Segmented(this, listOf("480p", "720p", "1080p", "Max"), qIndex) { i ->
            Prefs.get(this).edit().putInt(Prefs.KEY_QUALITY, qualityValues[i]).apply()
        })
        qualityCard.addView(
            text(
                "Max renders at your screen's full resolution. Lower options save battery. " +
                    "Your video file is never re-encoded or changed.",
                12f, TEXT_SECONDARY
            ).apply { setPadding(dp(4), dp(10), dp(4), 0) }
        )
        content.addView(qualityCard)

        // Playback
        content.addView(sectionLabel("PLAYBACK"))
        val playCard = card()
        playCard.addView(text("Speed", 16f, TEXT_PRIMARY))
        val sIndex = speedValues.indexOfFirst { it == Prefs.speed(this) }.let { if (it < 0) 1 else it }
        playCard.addView(
            Segmented(this, listOf("0.5×", "1×", "1.5×", "2×"), sIndex) { i ->
                Prefs.get(this).edit().putFloat(Prefs.KEY_SPEED, speedValues[i]).apply()
            },
            LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }
        )
        playCard.addView(text("Framing", 16f, TEXT_PRIMARY).apply { setPadding(0, dp(16), 0, 0) })
        playCard.addView(
            Segmented(this, listOf("Fill screen", "Stretch"), if (Prefs.crop(this)) 0 else 1) { i ->
                Prefs.get(this).edit().putBoolean(Prefs.KEY_CROP, i == 0).apply()
            },
            LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }
        )
        playCard.addView(
            row("Freeze in Battery Saver", styledSwitch(this, Prefs.freezeOnSaver(this)) { on ->
                Prefs.get(this).edit().putBoolean(Prefs.KEY_SAVER, on).apply()
            }).apply { setPadding(0, dp(16), 0, 0) }
        )
        content.addView(playCard)

        // Recent videos
        recentSection = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        recentSection.addView(sectionLabel("RECENT VIDEOS"))
        val recentCard = card()
        val hscroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        recentRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        hscroll.addView(recentRow)
        recentCard.addView(hscroll)
        recentCard.addView(
            text("Tap to switch · Long-press to remove", 12f, TEXT_SECONDARY)
                .apply { setPadding(dp(4), dp(10), dp(4), 0) }
        )
        recentSection.addView(recentCard)
        content.addView(recentSection)
    }

    // ───────────────────────── view helpers ─────────────────────────

    private fun text(s: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = sp
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun sectionLabel(s: String) = text(s, 12f, TEXT_SECONDARY, bold = true).apply {
        letterSpacing = 0.08f
        setPadding(dp(8), dp(22), 0, dp(8))
    }

    private fun card(strong: Boolean = false, pad: Int = 16) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = glass(this@MainActivity, 24, strong)
        setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
    }

    private fun row(title: String, trailing: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(text(title, 16f, TEXT_PRIMARY), LinearLayout.LayoutParams(0, WRAP, 1f))
        addView(trailing)
    }

    private fun pill(label: String, filled: Boolean) = text(label, 16f, TEXT_PRIMARY, bold = true).apply {
        gravity = Gravity.CENTER
        background = if (filled) solid(this@MainActivity, IOS_BLUE, 18) else glass(this@MainActivity, 18, true)
        pressable()
    }

    // ───────────────────────── data / actions ─────────────────────────

    private fun refresh() {
        val cur = Prefs.videoUri(this)
        if (cur == null) {
            nameTv.text = "No video selected"
            infoTv.text = "Choose a video to get started"
            previewImg.setImageDrawable(null)
            previewEmpty.visibility = View.VISIBLE
            applyBtn.isEnabled = false
            applyBtn.alpha = 0.4f
        } else {
            val uri = Uri.parse(cur)
            previewEmpty.visibility = View.GONE
            applyBtn.isEnabled = true
            applyBtn.alpha = 1f
            nameTv.text = displayName(uri) ?: "Video"
            infoTv.text = "Reading details…"
            loadThumb(cur) { previewImg.setImageBitmap(it) }
            loadInfo(cur)
        }
        buildRecent()
    }

    private fun buildRecent() {
        recentRow.removeAllViews()
        val list = Prefs.recent(this)
        recentSection.visibility = if (list.size > 1) View.VISIBLE else View.GONE
        val cur = Prefs.videoUri(this)
        for (u in list) {
            val selected = u == cur
            val wrap = FrameLayout(this).apply {
                setPadding(dp(3), dp(3), dp(3), dp(3))
                background = GradientDrawable().apply {
                    cornerRadius = dp(18).toFloat()
                    setStroke(dp(2), if (selected) IOS_BLUE else Color.TRANSPARENT)
                }
            }
            val img = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                background = solid(this@MainActivity, 0x22FFFFFF, 14)
                roundClip(dp(14).toFloat())
            }
            wrap.addView(img, FrameLayout.LayoutParams(dp(72), dp(128)))
            loadThumb(u) { img.setImageBitmap(it) }
            wrap.pressable()
            wrap.setOnClickListener {
                Prefs.select(this, u)
                refresh()
            }
            wrap.setOnLongClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                releaseUri(u)
                Prefs.remove(this, u)
                Toast.makeText(this, "Removed", Toast.LENGTH_SHORT).show()
                refresh()
                true
            }
            recentRow.addView(wrap, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(8) })
        }
    }

    private fun loadThumb(key: String, done: (Bitmap) -> Unit) {
        cache.get(key)?.let {
            done(it)
            return
        }
        io.execute {
            val b = extractFrame(Uri.parse(key)) ?: return@execute
            cache.put(key, b)
            runOnUiThread { if (!isDestroyed) done(b) }
        }
    }

    private fun loadInfo(key: String) {
        io.execute {
            val s = readInfo(Uri.parse(key))
            runOnUiThread {
                if (!isDestroyed && Prefs.videoUri(this) == key) infoTv.text = s
            }
        }
    }

    private fun extractFrame(uri: Uri): Bitmap? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(this, uri)
            val f = r.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: return null
            if (f.width <= 360) {
                f
            } else {
                val h = (f.height * 360f / f.width).toInt().coerceAtLeast(1)
                val small = Bitmap.createScaledBitmap(f, 360, h, true)
                if (small !== f) f.recycle()
                small
            }
        } catch (_: Exception) {
            null
        } finally {
            try {
                r.release()
            } catch (_: Exception) {
            }
        }
    }

    private fun readInfo(uri: Uri): String {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(this, uri)
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) {
                val t = w
                w = h
                h = t
            }
            val ms = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val sec = ms / 1000
            val dur = "%d:%02d".format(sec / 60, sec % 60)
            if (w > 0 && h > 0) "$w × $h · $dur" else dur
        } catch (_: Exception) {
            "Can't read details of this video"
        } finally {
            try {
                r.release()
            } catch (_: Exception) {
            }
        }
    }

    private fun displayName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    } catch (_: Exception) {
        null
    }

    private fun pickVideo() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            )
        }
        @Suppress("DEPRECATION")
        startActivityForResult(intent, REQ_PICK)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PICK || resultCode != RESULT_OK) return
        val uri = data?.data ?: return

        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
            Toast.makeText(this, "Couldn't access that video. Try another file.", Toast.LENGTH_LONG).show()
            return
        }

        // Free permissions of videos that fell off the recent list (Android limits how many we can hold).
        Prefs.select(this, uri.toString()).forEach { releaseUri(it) }
        refresh()

        if (isOurWallpaperActive()) {
            Toast.makeText(this, "Wallpaper updated", Toast.LENGTH_SHORT).show()
        } else {
            openWallpaperSetter()
        }
    }

    private fun releaseUri(u: String) {
        try {
            contentResolver.releasePersistableUriPermission(Uri.parse(u), Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }
    }

    private fun isOurWallpaperActive(): Boolean =
        WallpaperManager.getInstance(this).wallpaperInfo?.packageName == packageName

    private fun openWallpaperSetter() {
        val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
            WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
            ComponentName(this, VideoWallpaperService::class.java)
        )
        try {
            startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            // Some phones don't support the direct screen; fall back to the system chooser.
            try {
                startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
            } catch (_: ActivityNotFoundException) {
            }
        }
    }

    private companion object {
        const val REQ_PICK = 1001
        const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    }
}
